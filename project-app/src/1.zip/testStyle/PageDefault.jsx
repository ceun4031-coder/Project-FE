import Button from "../components/common/Button.jsx";


function PageDefault() {
  return (
   <div className="page-container">
  <h1>Dashboard</h1>
</div>

  );
}

export default PageDefault;
